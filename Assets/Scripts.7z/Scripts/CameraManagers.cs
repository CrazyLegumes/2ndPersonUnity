﻿using UnityEngine;
using System.Collections;
using DG.Tweening;


public class CameraManagers : MonoBehaviour
{
    [SerializeField]
    GameObject player1;
    [SerializeField]
    GameObject player2;
    public bool ready;

    // Use this for initialization
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {

    }


    public IEnumerator CameraSwitch(Player target)
    {
        
        ready = false;
        Vector3 leftbound = target.head.transform.position - new Vector3(.4f, .4f, .4f);

        Vector3 rightbound = target.head.transform.position + new Vector3(.4f, .4f, .4f);
        Vector3 RightCameraBound = new Vector3(target.head.transform.eulerAngles.x + .2f, target.transform.eulerAngles.y + .2f, target.transform.eulerAngles.z + .2f);
        Vector3 LeftCameraBound = new Vector3(target.head.transform.eulerAngles.x - .2f, target.transform.eulerAngles.y - .2f, target.transform.eulerAngles.z - .2f);

        

        transform.DOMove(target.head.transform.position, 3f);
        transform.DORotate(new Vector3(target.head.transform.eulerAngles.x, target.transform.eulerAngles.y, target.transform.eulerAngles.z), 2f);
       
        while (!ready)
        {
            yield return null;
            bool inposbounds = ((transform.position.x >= leftbound.x && transform.position.y >= leftbound.y && transform.position.z >= leftbound.z)
                && (transform.position.x <= rightbound.x && transform.position.y <= rightbound.y && transform.position.z <= rightbound.z));

            bool incamerabounds = (transform.eulerAngles.x >= LeftCameraBound.x && transform.eulerAngles.y >= LeftCameraBound.y) &&
                (transform.eulerAngles.x <= RightCameraBound.x && transform.eulerAngles.y <= RightCameraBound.y);




            if (inposbounds && incamerabounds)
            {
                ready = true;
                yield break;
            }       
        }

    }

   
}
